# ARGOS Brand Guidelines

Brand guideline website for ARGOS: brand strategy, visual identity and applications, with working tools for exporting on-brand assets.

**Status:** Work in progress (v0.9, November 2026)

## What's inside

- **Brand Strategy:** foundations, audience and positioning, voice and tone, voice checker
- **Visual Identity:** logo (grid, lockups, misuse, export, logo forms), color (palette, pairings, tokens), typography, Market Tides motif, icons, illustration, photography
- **In Use:** brand applications, quick rules and open review items

## Structure

```
index.html          The whole site (HTML, CSS and JavaScript in one file)
assets/vectors.js   Logo, motif and icon vector paths
assets/*.jpg|png    Photography, applications and reference images
.nojekyll           Tells GitHub Pages to serve files as-is
```

No build step and no dependencies. The only external resource is Google Fonts.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Publish with GitHub Pages

1. Create a new repository on GitHub and push these files to the `main` branch.
2. In the repository, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, then **Save**.
4. The site will be live at `https://<your-username>.github.io/<repository-name>/` after a minute or two.

## Fonts

The brand typeface is **Elza**, which is licensed and not included in this repository. The site uses Elza if it is installed on the viewer's device and falls back to Figtree (Google Fonts) otherwise. To serve Elza on the web, add your licensed webfont files and an `@font-face` rule for `"Elza"` at the top of the `<style>` block in `index.html`.

## Editing

- Colors: `COLORS` array and the `:root` tokens in `index.html`
- Open review items: `ISS` array in `index.html`
- Section copy: plain HTML inside each `<section>`
